<html>
<head>
<title>Appointment Booking</title>
</head>
<body>
<h2>Appointment Booking System</h2>

<form action="book.jsp" method="post">
Name: <input type="text" name="name"><br><br>
Email: <input type="email" name="email"><br><br>
Date: <input type="date" name="date"><br><br>
Time: <input type="time" name="time"><br><br>

<input type="submit" value="Book Appointment">
</form>
<style>
body {
    font-family: Arial, sans-serif;
    margin: 40px;
}
h2 {
    color: blue;
}
input {
    margin: 5px;
    padding: 5px;
}
</style>

</body>
</html>