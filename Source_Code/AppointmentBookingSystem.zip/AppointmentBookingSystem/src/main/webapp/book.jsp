<%@ page import="java.sql.*" %>

<%
String name = request.getParameter("name");
String email = request.getParameter("email");
String date = request.getParameter("date");
String time = request.getParameter("time");

try {

    Class.forName("com.mysql.cj.jdbc.Driver");

    Connection con = DriverManager.getConnection(
        "jdbc:mysql://localhost:3306/appointmentdb",
        "root",
        "mansi143"
    );

    PreparedStatement ps = con.prepareStatement(
        "INSERT INTO appointments(name,email,appointment_date,appointment_time) VALUES(?,?,?,?)"
    );

    ps.setString(1, name);
    ps.setString(2, email);
    ps.setString(3, date);
    ps.setString(4, time);

    int i = ps.executeUpdate();

    if(i > 0){
%>

<h2>Appointment Booked Successfully!</h2>

<p>Name: <%= name %></p>
<p>Email: <%= email %></p>
<p>Date: <%= date %></p>
<p>Time: <%= time %></p>

<%
    }

    con.close();

} catch(Exception e){
    out.println("Error:"+e.getMessage());
}
%>